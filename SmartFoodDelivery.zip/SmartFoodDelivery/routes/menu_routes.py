print("MENU ROUTES LOADED")

from fastapi import APIRouter
from models.menu_item import MenuItem
from database.mongodb import menu_items

router = APIRouter()


@router.post("/menu-items")
def create_menu_item(item: MenuItem):

    menu_items.insert_one(
    item.model_dump()
)

    return {
        "message": "Menu Item Added Successfully"
    }


@router.get("/menu-items")
def get_menu_items():

    data = []

    for item in menu_items.find():

        item["_id"] = str(item["_id"])

        data.append(item)

    return data


@router.get("/menu-items/{item_id}")
def get_menu_item(item_id: str):

    item = menu_items.find_one(
        {"itemId": item_id}
    )

    if item:

        item["_id"] = str(item["_id"])

        return item

    return {
        "message": "Menu Item Not Found"
    }


@router.put("/menu-items/{item_id}")
def update_menu_item(
    item_id: str,
    item: MenuItem
):

    menu_items.update_one(
        {"itemId": item_id},
        {"$set": item.model_dump()}
    )

    return {
        "message": "Menu Item Updated Successfully"
    }


@router.delete("/menu-items/{item_id}")
def delete_menu_item(item_id: str):

    menu_items.delete_one(
        {"itemId": item_id}
    )

    return {
        "message": "Menu Item Deleted Successfully"
    }

@router.get("/menu-items/restaurant/{restaurant_id}")
def get_menu_by_restaurant(restaurant_id: str):

    data = []

    for item in menu_items.find(
        {"restaurantId": restaurant_id}
    ):

        item["_id"] = str(item["_id"])

        data.append(item)

    return data

@router.get("/menu-items/restaurant/{restaurant_id}")
def get_menu_by_restaurant(restaurant_id: str):

    data = []

    for item in menu_items.find(
        {"restaurantId": restaurant_id}
    ):

        item["_id"] = str(item["_id"])

        data.append(item)

    return data