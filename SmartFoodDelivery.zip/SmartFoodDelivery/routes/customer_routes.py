from fastapi import APIRouter
from models.customer import Customer
from database.mongodb import customers

router = APIRouter()

@router.post("/customers")
def create_customer(customer: Customer):

    customers.insert_one(
    customer.model_dump()
)

    return {
        "message": "Customer Added Successfully"
    }

@router.get("/customers")
def get_customers():

    data = []

    for customer in customers.find():

        customer["_id"] = str(customer["_id"])

        data.append(customer)

    return data


@router.get("/customers/{customer_id}")
def get_customer(customer_id: str):

    customer = customers.find_one(
        {"customerId": customer_id}
    )

    if customer:

        customer["_id"] = str(customer["_id"])

        return customer

    return {
        "message": "Customer Not Found"
    }


@router.put("/customers/{customer_id}")
def update_customer(
    customer_id: str,
    customer: Customer
):

    customers.update_one(
    {"customerId": customer_id},
    {"$set": customer.model_dump()}
)

    return {
        "message": "Customer Updated Successfully"
    }


@router.delete("/customers/{customer_id}")
def delete_customer(customer_id: str):

    customers.delete_one(
        {"customerId": customer_id}
    )

    return {
        "message": "Customer Deleted Successfully"
    }