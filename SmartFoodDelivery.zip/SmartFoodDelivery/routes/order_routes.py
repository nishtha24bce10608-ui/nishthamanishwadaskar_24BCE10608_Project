print("ORDER ROUTES LOADED")

from fastapi import APIRouter
from models.order import Order
from database.mongodb import orders

router = APIRouter()

@router.post("/orders")
def create_order(order: Order):

    orders.insert_one(
    order.model_dump()
)

    return {
        "message": "Order Added Successfully"
    }


@router.get("/orders")
def get_orders():

    data = []

    for order in orders.find():

        order["_id"] = str(order["_id"])

        data.append(order)

    return data


@router.get("/orders/{order_id}")
def get_order(order_id: str):

    order = orders.find_one(
        {"orderId": order_id}
    )

    if order:

        order["_id"] = str(order["_id"])

        return order

    return {
        "message": "Order Not Found"
    }


@router.put("/orders/{order_id}")
def update_order(order_id: str, order: Order):

    menu_items.update_one(
    {"itemId": item_id},
    {"$set": item.model_dump()}
)

    return {
        "message": "Order Updated Successfully"
    }


@router.delete("/orders/{order_id}")
def delete_order(order_id: str):

    orders.delete_one(
        {"orderId": order_id}
    )

    return {
        "message": "Order Deleted Successfully"
    }

@router.get("/orders/customer/{customer_id}")
def get_customer_orders(customer_id: str):

    data = []

    for order in orders.find(
        {"customerId": customer_id}
    ):

        order["_id"] = str(order["_id"])

        data.append(order)

    return data

@router.put("/orders/{order_id}/status/{status}")
def update_order_status(
    order_id: str,
    status: str
):

    orders.update_one(
        {"orderId": order_id},
        {
            "$set": {
                "status": status
            }
        }
    )

    return {
        "message": "Order Status Updated Successfully"
    }

@router.get("/orders/customer/{customer_id}")
def get_customer_orders(customer_id: str):

    data = []

    for order in orders.find(
        {"customerId": customer_id}
    ):

        order["_id"] = str(order["_id"])

        data.append(order)

    return data

@router.put("/orders/{order_id}/status/{status}")
def update_order_status(
    order_id: str,
    status: str
):

    orders.update_one(
        {"orderId": order_id},
        {
            "$set": {
                "status": status
            }
        }
    )

    return {
        "message": "Order Status Updated Successfully"
    }