from fastapi import APIRouter
from models.payment import Payment
from database.mongodb import payments

router = APIRouter()

@router.post("/payments")
def create_payment(payment: Payment):

    payments.insert_one(
    payment.model_dump()
)

    return {
        "message": "Payment Added Successfully"
    }


@router.get("/payments")
def get_payments():

    data = []

    for payment in payments.find():

        payment["_id"] = str(payment["_id"])

        data.append(payment)

    return data


@router.get("/payments/{payment_id}")
def get_payment(payment_id: str):

    payment = payments.find_one(
        {"paymentId": payment_id}
    )

    if payment:

        payment["_id"] = str(payment["_id"])

        return payment

    return {
        "message": "Payment Not Found"
    }


@router.put("/payments/{payment_id}")
def update_payment(payment_id: str, payment: Payment):

    payments.update_one(
        {"paymentId": payment_id},
        {"$set": payment.model_dump()}
    )

    return {
        "message": "Payment Updated Successfully"
    }


@router.delete("/payments/{payment_id}")
def delete_payment(payment_id: str):

    payments.delete_one(
        {"paymentId": payment_id}
    )

    return {
        "message": "Payment Deleted Successfully"
    }