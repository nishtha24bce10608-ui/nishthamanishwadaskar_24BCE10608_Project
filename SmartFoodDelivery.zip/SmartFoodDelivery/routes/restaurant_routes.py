print("RESTAURANT ROUTES LOADED")

from fastapi import APIRouter
from models.restaurant import Restaurant
from database.mongodb import restaurants

router = APIRouter()


# CREATE RESTAURANT
@router.post("/restaurants")
def create_restaurant(restaurant: Restaurant):

    try:
        print("POST RESTAURANT HIT")

        data = restaurant.model_dump()
        print("DATA =", data)

        result = restaurants.insert_one(data)

        print("INSERTED ID =", result.inserted_id)

        return {
            "message": "Restaurant Added Successfully"
        }

    except Exception as e:
        print("ERROR =", str(e))

        return {
            "error": str(e)
        }


# GET ALL RESTAURANTS
@router.get("/restaurants")
def get_restaurants():

    data = []

    for restaurant in restaurants.find():

        restaurant["_id"] = str(
            restaurant["_id"]
        )

        data.append(
            restaurant
        )

    return data


# GET RESTAURANT BY ID
@router.get("/restaurants/{restaurant_id}")
def get_restaurant(restaurant_id: str):

    restaurant = restaurants.find_one(
        {
            "restaurantId": restaurant_id
        }
    )

    if restaurant:

        restaurant["_id"] = str(
            restaurant["_id"]
        )

        return restaurant

    return {
        "message": "Restaurant Not Found"
    }


# UPDATE RESTAURANT
@router.put("/restaurants/{restaurant_id}")
def update_restaurant(
    restaurant_id: str,
    restaurant: Restaurant
):

    restaurants.update_one(
        {
            "restaurantId": restaurant_id
        },
        {
            "$set": restaurant.model_dump()
        }
    )

    return {
        "message": "Restaurant Updated Successfully"
    }


# DELETE RESTAURANT
@router.delete("/restaurants/{restaurant_id}")
def delete_restaurant(
    restaurant_id: str
):

    restaurants.delete_one(
        {
            "restaurantId": restaurant_id
        }
    )

    return {
        "message": "Restaurant Deleted Successfully"
    }


# SEARCH RESTAURANTS BY LOCATION
@router.get("/restaurants/location/{location}")
def get_restaurants_by_location(location: str):

    data = []

    for restaurant in restaurants.find(
        {
            "location": location
        }
    ):

        restaurant["_id"] = str(
            restaurant["_id"]
        )

        data.append(
            restaurant
        )

    return data