from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")

db = client["food_delivery_db"]

restaurants = db["restaurants"]

customers = db["customers"]

menu_items = db["menu_items"]

orders = db["orders"]

payments = db["payments"]

print("CUSTOMERS COLLECTION LOADED")