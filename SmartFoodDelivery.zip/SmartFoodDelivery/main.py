from fastapi import FastAPI

from routes.restaurant_routes import router as restaurant_router
from routes.customer_routes import router as customer_router
from routes.menu_routes import router as menu_router
from routes.order_routes import router as order_router
from routes.payment_routes import router as payment_router

from database.mongodb import (
    restaurants,
    customers,
    menu_items,
    orders,
    payments
)
app = FastAPI(
    title="Smart Food Delivery Management System"
)

@app.get("/")
def home():
    return {
        "message": "Smart Food Delivery Management System"
    }

app.include_router(restaurant_router)
app.include_router(customer_router)
app.include_router(menu_router)
app.include_router(order_router)
app.include_router(payment_router)

@app.get("/stats")
def get_stats():

    return {
        "total_restaurants": restaurants.count_documents({}),
        "total_customers": customers.count_documents({}),
        "total_menu_items": menu_items.count_documents({}),
        "total_orders": orders.count_documents({}),
        "total_payments": payments.count_documents({})
    }

from database.mongodb import (
    restaurants,
    customers,
    menu_items,
    orders,
    payments
)

@app.get("/stats")
def get_stats():

    return {
        "total_restaurants": restaurants.count_documents({}),
        "total_customers": customers.count_documents({}),
        "total_menu_items": menu_items.count_documents({}),
        "total_orders": orders.count_documents({}),
        "total_payments": payments.count_documents({})
    }