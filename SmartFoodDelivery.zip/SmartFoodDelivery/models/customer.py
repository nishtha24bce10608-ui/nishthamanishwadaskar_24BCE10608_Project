from pydantic import BaseModel

class Customer(BaseModel):
    customerId: str
    name: str
    email: str
    phone: str
    address: str