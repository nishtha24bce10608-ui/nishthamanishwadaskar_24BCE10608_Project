from pydantic import BaseModel

class Payment(BaseModel):
    paymentId: str
    orderId: str
    amount: float
    paymentMethod: str
    paymentStatus: str