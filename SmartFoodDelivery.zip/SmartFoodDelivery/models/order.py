from pydantic import BaseModel
from typing import List

class Order(BaseModel):
    orderId: str
    customerId: str
    itemIds: List[str]
    totalAmount: float
    status: str