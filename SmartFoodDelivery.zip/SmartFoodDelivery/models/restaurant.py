from pydantic import BaseModel

class Restaurant(BaseModel):
    restaurantId: str
    name: str
    location: str
    rating: float
    contactNumber: str