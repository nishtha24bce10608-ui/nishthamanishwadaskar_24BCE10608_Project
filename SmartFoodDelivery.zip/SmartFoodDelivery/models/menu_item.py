from pydantic import BaseModel

class MenuItem(BaseModel):
    itemId: str
    itemName: str
    price: float
    category: str
    restaurantId: str